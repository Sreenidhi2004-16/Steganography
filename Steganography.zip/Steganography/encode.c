#include <stdio.h>
#include "encode.h"
#include "types.h"
#include<string.h>
#include "common.h"

/* Function Definitions */

/* Get image size
 * Input: Image file ptr
 * Output: width * height * bytes per pixel (3 in our case)
 * Description: In BMP Image, width is stored in offset 18,
 * and height after that. size is 4 bytes
 */
uint get_image_size_for_bmp(FILE *fptr_image)
{
    uint width, height;
    // Seek to 18th byte
    fseek(fptr_image, 18, SEEK_SET);

    // Read the width (an int)
    fread(&width, sizeof(int), 1, fptr_image);
    printf("width = %u\n", width);

    // Read the height (an int)
    fread(&height, sizeof(int), 1, fptr_image);
    printf("height = %u\n", height);

    // Return image capacity
    return width * height * 3;
}

uint get_file_size(FILE *fptr)
{
    // Find the size of secret file data
    // return secret file size

    // Move file pointer to the end
    fseek(fptr, 0, SEEK_END);

    // Get the current position, which is the file size
    uint file_size = ftell(fptr);

    // Move the file pointer back to the beginning
    rewind(fptr);

    // Return file size
    return file_size;
}

/*
 * Get File pointers for i/p and o/p files
 * Inputs: Src Image file, Secret file and
 * Stego Image file
 * Output: FILE pointer for above files
 * Return Value: e_success or e_failure, on file errors
 */

Status read_and_validate_encode_args(char *argv[], EncodeInfo *encInfo)
{
    // step 1 -> check argv[2] is having .bmp or not
        //yes -> store the file name into encInfo -> src_image_fname = argv[2]
        //no - > return e_failure
        if(argv[2] == NULL)
        {
            printf("Error: Source image file not found\n");
            return e_failure;
        }
        if(strrchr(argv[2] , '.') == NULL)
        {
        printf("Error: .bmp not found\n");
        return e_failure;
        }
     
        if(strcmp(strrchr(argv[2] , '.') , ".bmp") == 0)
        encInfo -> src_image_fname = argv[2];
    
        else
        {
        printf("Error: Extention should be .bmp\n");
        return e_failure;
        }
        

    // step 2 -> check argv[3] is having extn there or not
        // yes - > store the file name into encInfo -> secret_fname = argv[3]
        // no -> return e_failure
        // (also store the extension from . --- extn_secret_file[5] )
        char *extn;
        if(argv[3] == NULL)
        {
            printf("Error: Secret file not found!\n");
            return e_failure;
        }
        if ( strrchr(argv[3], '.') == NULL)
        {
           printf("Error: Secret file extension not found\n");
           return e_failure;
        }
        else
        {
            extn = strrchr(argv[3], '.');
            encInfo->secret_fname = argv[3];

            if(strlen(extn) < sizeof(encInfo->extn_secret_file))
            strcpy(encInfo->extn_secret_file, extn);

            else
            {
               printf("Error: Extention size is greater \n");
               return e_failure;
            }
        }
    
    // step 3 -> check argv[4] is NULL or not
        //yes -> check argv[4] is having .bmp or not
                //yes -> store the file name into encInfo -> stego_image_fname = argv[4]
                //no - > return e_failure
        
        //no -> store default name the encInfo -> stego_image_fname = "stego.bmp"
        char *ptr;
        if (argv[4] != NULL)
        {
            ptr = strrchr(argv[4], '.');

    // Check whether extension exists
    if (ptr == NULL)
    {
        printf("Error: Output file extension not found\n");
        return e_failure;
    }

    // Check whether extension is .bmp
    if (strcmp(ptr, ".bmp") == 0)
    {
        encInfo->stego_image_fname = argv[4];
    }
    else
    {
        printf("Error: Output image should be a .bmp file\n");
        return e_failure;
    }
}
else
{
    // If output filename is not given, use default name
    encInfo->stego_image_fname = "stego.bmp";
}

    return e_success;
}


Status open_files(EncodeInfo *encInfo)
{
    // Src Image file
    encInfo->fptr_src_image = fopen(encInfo->src_image_fname, "rb");
    // Do Error handling
    if (encInfo->fptr_src_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->src_image_fname);

        return e_failure;
    }

    // Secret file
    encInfo->fptr_secret = fopen(encInfo->secret_fname, "rb");
    // Do Error handling
    if (encInfo->fptr_secret == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->secret_fname);

        return e_failure;
    }

    // Stego Image file
    encInfo->fptr_stego_image = fopen(encInfo->stego_image_fname, "wb");
    // Do Error handling
    if (encInfo->fptr_stego_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->stego_image_fname);

        return e_failure;
    }

    // No failure return e_success
    return e_success;
}

Status check_capacity(EncodeInfo *encInfo)
{
    //step 1 -> encInfo -> image_capacity = call get_image_size_for_bmp(encoInfo -> fptr_src_image)
            encInfo -> image_capacity =  get_image_size_for_bmp(encInfo -> fptr_src_image);

    //step 2 -> encInfo -> size_secret_file = call get_file_size(encInfo -> fptr_secret)
            encInfo -> size_secret_file = get_file_size(encInfo -> fptr_secret);


    //step 3 -> check encInfo -> image_capacity > 16 + 32 + (strlen(encInfo -> extn_secret_file) * 8) + 32 + (encInfo -> size_secret_file * 8)
                //t -> return e_success;
                //f -> return e_failure
                if(encInfo -> image_capacity >= 16 + 32 + (strlen(encInfo -> extn_secret_file) * 8) + 32 + (encInfo -> size_secret_file * 8))
                return e_success;
                else
                return e_failure;
}


Status copy_bmp_header(FILE *fptr_src_image, FILE *fptr_dest_image)
{
    char header[54];
    // step 1 -> rewind source file pointer
    rewind(fptr_src_image);

    // step 2 -> read 54 bytes from source file
    if(fread(header, sizeof(char), 54, fptr_src_image) != 54)
    return e_failure;

    // step 3 -> write 54 bytes to dest file
    if(fwrite(header, sizeof(char), 54, fptr_dest_image) != 54)
    return e_failure;

    // return e_success
    return e_success;
}
Status encode_magic_string(const char *magic_string, EncodeInfo *encInfo)
{
    // char buffer[8];
       char buffer[8];
       int i = 0;

    while(magic_string[i] != '\0')
    {
    //step 1 -> read 8 bytes from source file
    if(fread(buffer,sizeof(char),8,encInfo->fptr_src_image) != 8)
    return e_failure;

    //step 2 -> call encode_byte_to_lsb(magic_string[i], buffer)
    if(encode_byte_to_lsb(magic_string[i], buffer) != e_success)
    return e_failure;

    //step 3 -> write the buffer into dest file
    if(fwrite(buffer,sizeof(char),8,encInfo->fptr_stego_image) != 8)
    return e_failure;

    i++;
    }
    // repeat this for strlen(magic_string) times from step 1
    return e_success;
}

Status encode_secret_file_extn_size(int size, EncodeInfo *encInfo)
{
    // char buffer[32];
    char buffer[32];

    //step 1 -> read 32 bytes from source file
    if(fread(buffer,32,1,encInfo->fptr_src_image) != 1)
    return e_failure;

    //step 2 -> call encode_size_to_lsb(size, buffer)
    if(encode_size_to_lsb(size, buffer) != e_success)
    return e_failure;

    //step 3 -> write the buffer into dest file
    if(fwrite(buffer,32,1,encInfo->fptr_stego_image) != 1)
    return e_failure;

    return e_success;

}

Status encode_secret_file_extn(const char *file_extn, EncodeInfo *encInfo)
{
    // char buffer[8];
    char buffer[8];

    for(int i=0; i<strlen(file_extn); i++)
    {
    //step 1 -> read 8 bytes from source file
    if(fread(buffer,8,1,encInfo->fptr_src_image) != 1)
    return e_failure;

    //step 2 -> call encode_byte_to_lsb(file_extn[i], buffer)
    if(encode_byte_to_lsb(file_extn[i], buffer) != e_success)
    return e_failure;

    //step 3 -> write the buffer into dest file
    if(fwrite(buffer,8,1,encInfo->fptr_stego_image) != 1)
    return e_failure;
    }
    // repeat this for strlen(file_extn) times from step 1 
    return e_success;
  
}

Status encode_secret_file_size(long file_size, EncodeInfo *encInfo)
{
    // char buffer[32];
    char buffer[32];

    //step 1 -> read 32 bytes from source file
    if(fread(buffer,32,1,encInfo->fptr_src_image) != 1)
    return e_failure;

    //step 2 -> call encode_size_to_lsb(file_size, buffer)
    if(encode_size_to_lsb(file_size, buffer) != e_success)
    return e_failure;

    //step 3 -> write the buffer into dest file
    if(fwrite(buffer,32,1,encInfo->fptr_stego_image) != 1)
    return e_failure;

    return e_success;
}

Status encode_secret_file_data(EncodeInfo *encInfo)
{
    char buffer[8];
    char data;

    for (int i = 0; i < encInfo->size_secret_file; i++)
    {
        // Read one byte from secret file
        if (fread(&data, sizeof(char), 1, encInfo->fptr_secret) != 1)
        {
            return e_failure;
        }

        // Read 8 bytes from source image
        if (fread(buffer, sizeof(char), 8, encInfo->fptr_src_image) != 8)
        {
            return e_failure;
        }

        // Encode one secret byte into 8 image bytes
        if (encode_byte_to_lsb(data, buffer) != e_success)
        {
            return e_failure;
        }

        // Write encoded bytes to stego image
        if (fwrite(buffer, sizeof(char), 8, encInfo->fptr_stego_image) != 8)
        {
            return e_failure;
        }
    }

    return e_success;
}

Status copy_remaining_img_data(FILE *fptr_src, FILE *fptr_dest)
{
    // write logic for copy remaining data
    char buffer[8];
    size_t bytes_read;
    while ((bytes_read = fread(buffer, sizeof(char), 8, fptr_src)) > 0)
    {
        if(fwrite(buffer, sizeof(char), bytes_read, fptr_dest) != bytes_read)
        return e_failure;
    }

    // return e_success
       return e_success;
}

Status encode_byte_to_lsb(char data, char *image_buffer)
{
        // write logic to encode the char
        for(int i=0; i<8; i++)
        {
            //Clear
            image_buffer[i] = image_buffer[i] & ~1;

            //Get and Set
            image_buffer[i] = image_buffer[i] | (data >> (7-i)) & 1;
        }
        return e_success;
}

Status encode_size_to_lsb(int size, char *imageBuffer)
{
        // write logic to encode the int
                for(int i=0; i<32; i++)
        {
            //Clear
            imageBuffer[i] = imageBuffer[i] & ~1;

            //Get and Set
            imageBuffer[i] = imageBuffer[i] | (size >> (31-i)) & 1;
        }
        return e_success;   
}

Status do_encoding(EncodeInfo *encInfo)
{
    //step 1 -> check open_files(encInfo) is returning e_success or not
            //no -> print error return e_failure
            //yes -> print success and goto next step
            if(open_files(encInfo) != e_success)
            {
            printf("Error in opening the file\n");
            return e_failure;
            }

            else
            printf("File opened succesfully\n");

    //step 2 -> check check_capacity(encInfo) is returning e_success or not
            //no -> print error return e_failure
            //yes -> print success and goto next step
            if(check_capacity(encInfo) != e_success)
            {
                printf("Secret data cannot be fit in source image");
                return e_failure;
            }
            else
            printf("Hurry! The secret data can fit in the source image\n");

    //step 3 -> check copy_bmp_header(encInfo -> fptr_src_image, encInfo -> fptr_stego_image)is returning e_success or not
            //no -> print error return e_failure
            //yes -> print success and goto next step
            if(copy_bmp_header(encInfo -> fptr_src_image, encInfo -> fptr_stego_image) != e_success)
            {
                printf("Error: Header file couldn't copy form source file to destination file\n");
                return e_failure;
            }
            else
            printf("Header file successfully copied\n");

    //step 4 -> call encode_magic_string(MAGIC_STRING, encInfo)
    if(encode_magic_string(MAGIC_STRING, encInfo) != e_success)
    return e_failure;

    else
    {
       printf("Entered magic string successfully\n");
    }

    //step 5 -> call encode_secret_file_extn_size(strlen(encInfo -> extn_secret_file), encInfo)
    if(encode_secret_file_extn_size(strlen(encInfo -> extn_secret_file), encInfo) != e_success)
    return e_failure;

    else
    printf("Encoded secret file extention size successfully\n");

    //step 6 -> call encode_secret_file_extn(encInfo -> extn_secret_file, encInfo)
    if(encode_secret_file_extn(encInfo -> extn_secret_file, encInfo) != e_success)
    return e_failure;

    else
    printf("Encoded secret file extention successfully\n");

    //step 7 -> call encode_secret_file_size(encInfo ->  size_secret_file, encInfo)
    if(encode_secret_file_size(encInfo -> size_secret_file, encInfo) != e_success)
    return e_failure;

    else
    printf("Encoded secret file size successfully\n");

    //step 8 -> call encode_secret_file_data(encInfo)
    if(encode_secret_file_data(encInfo) != e_success)
    return e_failure;

    else
    printf("Encoded secret file data successfully\n");

    //step 9 -> check copy_remaining_img_data(encInfo -> fptr_src_image, encInfo -> fptr_stego_image)is returning e_success or not
            //no -> print error return e_failure
            //yes -> print success
            if(copy_remaining_img_data(encInfo -> fptr_src_image, encInfo -> fptr_stego_image) != e_success)
            {
                printf("Error: The remaining image data couldn't copy from source image to destination image\n");
                return e_failure;
            }
            else
            printf("The remaining image data successfully copied from source file to destionation file\n");


    // return e_success
    return e_success;
}