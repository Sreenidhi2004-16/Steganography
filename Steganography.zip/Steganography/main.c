//----------------Documentation----------------//
/*Name:Sreenidhi B S
  Project Name:Steganography 
  Description:Implementation of LSB (Least 
Significant Bit) Image Steganography on a .bmp file
*/


#include <stdio.h>
#include "encode.h"
#include "decode.h"
#include "types.h"
#include <string.h>

OperationType check_operation_type(char *);

int main(int argc, char *argv[]) // .aout -e <source_file> <secret_data_file> <optional>
{
    //step 1 -> check check_operation_type(argv[1]) is returning e_encode or not
        // yes -> EncodeInfo encInfo;
            // check read_and_validate_encode_args(argv, &encInfo) is returning e_success or e_failure
                // failure -> print error msg and stop
                // success -> print success msg 
                            // check do_encoding(&encInfo) is returning e_success or e_failure
                                    // failure -> print error msg and stop
                                    // success -> print success msg and stop

    //step 2 -> check check_operation_type(argv[1]) is returning e_decode or not
        // yes -> DecodeInfo decInfo;
            // check read_and_validate_decode_args(argv, &decInfo) is returning e_success or e_failure
                // failure -> print error msg and stop
                // success -> print success msg 
                            // check do_decoding(&decInfo) is returning e_success or e_failure
                                    // failure -> print error msg and stop
                                    // success -> print success msg and stop

    //step 3 -> check check_operation_type(argv[1]) is returning e_unsupported or not
        // yes -> print error msg and stop

    if (argc < 2)
    {
        printf("Error: Insufficient arguments\n");
        return e_failure;
    }
        if(check_operation_type(argv[1]) == e_encode)
        {
            EncodeInfo encInfo;
            if(read_and_validate_encode_args(argv, &encInfo) != e_success)
            {
                return e_failure;
            }
            else
            {
                    printf("Arguments validated successfully\n");               
                    if(do_encoding(&encInfo) != e_success)
                {
                    printf("Error: Encoding failed\n");
                    return e_failure;
                }

                else
                {
                    printf("Successfully encoded!\n");
                }
                    return e_success;

            }
        }

        else if(check_operation_type(argv[1]) == e_decode)
        {
            DecodeInfo decInfo;
            if(read_and_validate_decode_args(argv, &decInfo) != e_success)
            {
                return e_failure;
            }
            else
            {
                    printf("Arguments validated successfully\n");                
                    if(do_decoding(&decInfo) != e_success)
                {
                    printf("Error: Decoding failed\n");
                    return e_failure;
                }

                else
                {
                    printf("Successfully decoded!\n");
                }
                    return e_success;

            }
        }

        else if(check_operation_type(argv[1]) == e_unsupported)
        {
            printf("Enter a proper argument\n");
            return e_failure;
        }

}

OperationType check_operation_type(char *symbol)
{
    //step 1 -> check symbol is -e or not
        // yes -> return e_encode
        if(strcmp(symbol,"-e")==0)
        return e_encode;
    
    // step 2 -> check symbol is -d or not
        // yes -> return e_decode
        else if(strcmp(symbol,"-d")==0)
        return e_decode;

    // return e_unsupported
        else
        return e_unsupported;

}
