#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "decode.h"
#include "types.h"
#include "common.h"


/* Read and validate decode arguments */
Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo)
{
    char *ptr;

    /* Step 1: Check stego image */
    if (argv[2] == NULL)
    {
        printf("Error: Stego image not found\n");
        return e_failure;
    }

    ptr = strrchr(argv[2], '.');

    if (ptr == NULL)
    {
        printf("Error: Stego image extension not found\n");
        return e_failure;
    }

    if (strcmp(ptr, ".bmp") != 0)
    {
        printf("Error: Stego image should be .bmp\n");
        return e_failure;
    }

    decInfo->stego_image_fname = argv[2];


    /* Step 2: Check output file name */
    if (argv[3] != NULL)
    {
        decInfo->secret_fname = argv[3];
    }
    else
    {
        decInfo->secret_fname = "output";
    }

    return e_success;
}


/* Open stego image */
Status open_decode_files(DecodeInfo *decInfo)
{
    /* Open stego image in read mode */
    decInfo->fptr_stego_image =
        fopen(decInfo->stego_image_fname, "rb");

    if (decInfo->fptr_stego_image == NULL)
    {
        printf("Error: Unable to open stego image\n");
        return e_failure;
    }

    return e_success;
}


/* Decode one byte from LSB */
Status decode_byte_from_lsb(char *data, char *image_buffer)
{
    if (data == NULL || image_buffer == NULL)
    {
        return e_failure;
    }

    *data = 0;

    for (int i = 0; i < 8; i++)
    {
        /* Get LSB from image byte */
        char bit = image_buffer[i] & 1;

        /* Store bit in data */
        *data = *data | (bit << (7 - i));
    }

    return e_success;
}


/* Decode 32-bit integer from LSB */
Status decode_size_from_lsb(int *size, char *imageBuffer)
{
    if (size == NULL || imageBuffer == NULL)
    {
        return e_failure;
    }

    *size = 0;

    for (int i = 0; i < 32; i++)
    {
        /* Get LSB from image byte */
        int bit = imageBuffer[i] & 1;

        /* Reconstruct integer */
        *size = *size | (bit << (31 - i));
    }

    return e_success;
}


/* Decode magic string */
Status decode_magic_string(const char *magic_string,
                           DecodeInfo *decInfo)
{
    char buffer[8];
    char data;

    for (int i = 0; magic_string[i] != '\0'; i++)
    {
        /* Read 8 image bytes */
        if (fread(buffer, sizeof(char), 8,
                  decInfo->fptr_stego_image) != 8)
        {
            return e_failure;
        }

        /* Decode one character */
        if (decode_byte_from_lsb(&data, buffer) != e_success)
        {
            return e_failure;
        }

        /* Compare with expected magic character */
        if (data != magic_string[i])
        {
            printf("Error: Magic string does not match\n");
            return e_failure;
        }
    }

    return e_success;
}


/* Decode secret file extension size */
Status decode_secret_file_extn_size(int *size,
                                    DecodeInfo *decInfo)
{
    char buffer[32];

    /* Read 32 image bytes */
    if (fread(buffer, sizeof(char), 32,
              decInfo->fptr_stego_image) != 32)
    {
        return e_failure;
    }

    /* Decode size */
    if (decode_size_from_lsb(size, buffer) != e_success)
    {
        return e_failure;
    }

    return e_success;
}


/* Decode secret file extension */
Status decode_secret_file_extn(char *file_extn,
                               int size,
                               DecodeInfo *decInfo)
{
    char buffer[8];
    char data;

    for (int i = 0; i < size; i++)
    {
        /* Read 8 image bytes */
        if (fread(buffer, sizeof(char), 8,
                  decInfo->fptr_stego_image) != 8)
        {
            return e_failure;
        }

        /* Decode one character */
        if (decode_byte_from_lsb(&data, buffer) != e_success)
        {
            return e_failure;
        }

        file_extn[i] = data;
    }

    file_extn[size] = '\0';

    return e_success;
}


/* Decode secret file size */
Status decode_secret_file_size(long *file_size,
                               DecodeInfo *decInfo)
{
    char buffer[32];
    int size;

    /* Read 32 image bytes */
    if (fread(buffer, sizeof(char), 32,
              decInfo->fptr_stego_image) != 32)
    {
        return e_failure;
    }

    /* Decode size */
    if (decode_size_from_lsb(&size, buffer) != e_success)
    {
        return e_failure;
    }

    *file_size = size;

    return e_success;
}


/* Decode secret file data */
Status decode_secret_file_data(DecodeInfo *decInfo)
{
    char buffer[8];
    char data;

    for (long i = 0; i < decInfo->size_secret_file; i++)
    {
        /* Read 8 image bytes */
        if (fread(buffer, sizeof(char), 8,
                  decInfo->fptr_stego_image) != 8)
        {
            return e_failure;
        }

        /* Decode one byte */
        if (decode_byte_from_lsb(&data, buffer) != e_success)
        {
            return e_failure;
        }

        /* Write decoded byte to secret file */
        if (fwrite(&data, sizeof(char), 1,
                   decInfo->fptr_secret) != 1)
        {
            return e_failure;
        }
    }

    return e_success;
}


/* Perform decoding */
Status do_decoding(DecodeInfo *decInfo)
{
    int extn_size;
    char file_extn[5];

    /* Step 1: Open stego image */
    if (open_decode_files(decInfo) != e_success)
    {
        printf("Error: Unable to open stego image\n");
        return e_failure;
    }

    printf("Stego image opened successfully\n");


    /*
     * Move past the 54-byte BMP header.
     * Encoding started hiding data after the header.
     */
    if (fseek(decInfo->fptr_stego_image, 54, SEEK_SET) != 0)
    {
        printf("Error: Unable to seek BMP header\n");
        fclose(decInfo->fptr_stego_image);
        return e_failure;
    }


    /* Step 2: Decode magic string */
    if (decode_magic_string(MAGIC_STRING,
                            decInfo) != e_success)
    {
        printf("Error: Magic string verification failed\n");

        fclose(decInfo->fptr_stego_image);

        return e_failure;
    }

    printf("Magic string decoded successfully\n");


    /* Step 3: Decode extension size */
    if (decode_secret_file_extn_size(
            &extn_size, decInfo) != e_success)
    {
        printf("Error: Unable to decode extension size\n");

        fclose(decInfo->fptr_stego_image);

        return e_failure;
    }

    printf("Secret file extension size = %d\n", extn_size);


    /* Check extension size */
    if (extn_size <= 0 || extn_size >= sizeof(file_extn))
    {
        printf("Error: Invalid extension size\n");

        fclose(decInfo->fptr_stego_image);

        return e_failure;
    }


    /* Step 4: Decode extension */
    if (decode_secret_file_extn(
            file_extn,
            extn_size,
            decInfo) != e_success)
    {
        printf("Error: Unable to decode secret file extension\n");

        fclose(decInfo->fptr_stego_image);

        return e_failure;
    }

    printf("Secret file extension = %s\n", file_extn);


    /* Store extension */
    strcpy(decInfo->extn_secret_file, file_extn);


    /* Step 5: Decode secret file size */
    if (decode_secret_file_size(
            &decInfo->size_secret_file,
            decInfo) != e_success)
    {
        printf("Error: Unable to decode secret file size\n");

        fclose(decInfo->fptr_stego_image);

        return e_failure;
    }

    printf("Secret file size = %ld bytes\n",
           decInfo->size_secret_file);


    /* Step 6: Create output file */
    {
        char output_fname[100];

        strcpy(output_fname, decInfo->secret_fname);

        strcat(output_fname, decInfo->extn_secret_file);

        decInfo->fptr_secret =
            fopen(output_fname, "wb");

        if (decInfo->fptr_secret == NULL)
        {
            printf("Error: Unable to create output file\n");

            fclose(decInfo->fptr_stego_image);

            return e_failure;
        }

        printf("Output file created: %s\n", output_fname);
    }


    /* Step 7: Decode secret data */
    if (decode_secret_file_data(decInfo) != e_success)
    {
        printf("Error: Unable to decode secret data\n");

        fclose(decInfo->fptr_stego_image);
        fclose(decInfo->fptr_secret);

        return e_failure;
    }

    printf("Secret data decoded successfully\n");


    /* Close files */
    fclose(decInfo->fptr_stego_image);
    fclose(decInfo->fptr_secret);

    return e_success;
}